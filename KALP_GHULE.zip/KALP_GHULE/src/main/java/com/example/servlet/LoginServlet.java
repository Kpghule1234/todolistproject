package com.example.servlet;

import com.example.model.User;
import com.example.util.Database;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Check if user exists in the database (in-memory list for simplicity)
        for (User user : Database.getUsers()) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                response.sendRedirect("taskboard.jsp");
                return;
            }
        }

        response.sendRedirect("index.jsp"); // Redirect back to login if credentials are incorrect
    }
}
