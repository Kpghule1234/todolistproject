package com.example.servlet;

import com.example.model.TaskList;
import com.example.util.Database;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/addTaskList")
public class TaskListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String taskListName = request.getParameter("taskListName");
        TaskList taskList = new TaskList();

        Database.getTaskLists().add(taskList);

        response.sendRedirect("taskboard.jsp");
    }
}
