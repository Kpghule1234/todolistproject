package com.example.util;

import com.example.model.User;
import com.example.model.TaskList;

import java.util.ArrayList;
import java.util.List;

public class Database {
    private static List<User> users = new ArrayList<>();
    private static List<TaskList> taskLists = new ArrayList<>();

    public static List<User> getUsers() {
        return users;
    }

    public static List<TaskList> getTaskLists() {
        return taskLists;
    }
}
